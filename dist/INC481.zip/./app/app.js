$(document).ready(function() {
    app.initialized().then(function(_client) {
        var client = _client;
        //get iparam data
        client.iparams.get().then(function(iparamdata) {
            //get location
            client.instance.context().then(function(context) {
                var location = context.location;
                if (iparamdata.checkedNewTicket == location) {
                    hideDisableFunction(iparamdata);
                }
                if (iparamdata.checkedTicket == location) {
                    hideDisableFunction(iparamdata);
                }
            });
        }, function(error) {
            handleError(error);
        });

        function hideDisableFunction(iparamdata) {
            headers = {
                "Authorization": "Basic <%= encode(iparam.apiKey) %>",
                "Content-Type": "application/json;charset=UTF-8"
            };
            var options = {
                headers: headers
            };
            var ticket_fields_url = "https://<%= iparam.fdurl %>/api/v2/ticket_fields";
            //get the ticket fields
            client.request.get(ticket_fields_url, options).then(function(tdata) {
                var tfields = JSON.parse(tdata.response);
                var map = new Map();
                $.each(tfields, function(key, value) {
                    map[value.label] = value.name;
                });
                hide_disable_function(map, iparamdata);
            }, function(error) {
                handleError(error);
            });
        }

        //Function to hide/disable selected fields
        function hide_disable_function(map, iparamdata) {
            var agent_list = iparamdata.agent_list;
            client.data.get("loggedInUser").then(function(agent_data) {
                    var current_agent = agent_data.loggedInUser.contact.name;
                    if ($.inArray(current_agent, agent_list) != '-1') {
                        var hide_fields = iparamdata.hide_fields;
                        var disable_fields = iparamdata.disable_fields;
                        $.each(hide_fields, function(k, v) {
                            var field_id = map[v];
                            client.interface.trigger("hide", {
                                id: field_id
                            });
                        });
                        $.each(disable_fields, function(k1, v1) {
                            var field_id1 = map[v1];
                            client.interface.trigger("disable", {
                                id: field_id1
                            });
                        });
                    }
                },
                function(error) {
                    handleError(error);
                });
        }

        //Function to handle errors
        function handleError(e) {
            if (e.status === 400) {
                errorHandler("Invalid input entered, please verify the fields and try again.");
            } else if (e.status == 401) {
                errorHandler("Invalid API key was given, please check with your Freshdesk.");
            } else if (e.status === 429) {
                errorHandler("Too many requests were made, please try after sometime.");
            } else if (e.status === 500) {
                errorHandler("Unexpected error occurred, please try after sometime.");
            } else if (e.status === 502) {
                errorHandler("Error due to network issue, please try again.");
            } else if (e.status === 403) {
                errorHandler("Can't authenticate request, Please check with your Freshdesk.");
            } else {
                errorHandler(e.message);
            }
        }

        function errorHandler(message) {
            client.interface.trigger("showNotify", {
                type: "warning",
                message: message
            });
        }
    });
});